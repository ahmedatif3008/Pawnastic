package Pawntastic;

public enum Piece {
    EMPTY,
    WHITE,
    BLACK
}